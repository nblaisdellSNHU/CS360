package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class EnableSMSActivity extends AppCompatActivity {
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 0;
    public static final String EXTRA_ENABLE_SMS = "com.example.inventoryapp.enable_sms";

    private Button btnEnableSMS;
    private Button btnDisableSMS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enable_sms);
        getSupportActionBar().hide();

        // The "Enable" button will attempt to gain permissions to send SMS messages
        // on the user's behalf during this app, which will text the user
        // when inventory is low
        btnEnableSMS = findViewById(R.id.btnEnableSMS);
        btnEnableSMS.setOnClickListener(view -> {
            setSMSPermissions();
        });

        // The "Disable" button will allow the user to disable the SMS functionality.
        // The permission may still be allowed, but the texting functionality will not
        // work when disabled.
        btnDisableSMS = findViewById(R.id.btnDisableSMS);
        btnDisableSMS.setOnClickListener(view -> {
            Intent returnData = new Intent();
            returnData.putExtra(EXTRA_ENABLE_SMS, false);

            setResult(RESULT_OK, returnData);
            finish();
        });
    }

    protected void setSMSPermissions() {
        ActivityCompat.requestPermissions(
            this,
            new String[]{Manifest.permission.SEND_SMS},
            MY_PERMISSIONS_REQUEST_SEND_SMS
        );
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        SharedPreferences sharedPref = getApplicationContext().getSharedPreferences("myprefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();

        boolean useSMS = false;

        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_SEND_SMS: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    useSMS = true;
                    editor.putBoolean(InventoryActivity.PREF_SMS_ENABLED, true);

                    Toast.makeText(getApplicationContext(), "SMS Enabled", Toast.LENGTH_LONG).show();
                } else {
                    useSMS = false;
                    editor.putBoolean(InventoryActivity.PREF_SMS_ENABLED, false);

                    Toast.makeText(getApplicationContext(),"SMS Disabled", Toast.LENGTH_LONG).show();
                }
            }
        }

        editor.apply();

        Intent returnData = new Intent();
        returnData.putExtra(EXTRA_ENABLE_SMS, useSMS);

        setResult(RESULT_OK, returnData);
        finish();
    }
}