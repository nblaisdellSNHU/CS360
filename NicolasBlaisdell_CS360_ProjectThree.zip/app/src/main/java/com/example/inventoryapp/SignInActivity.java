package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.inventoryapp.database.InventoryDatabase;
import com.example.inventoryapp.database.InventoryDatabase.UserFoundResult;

public class SignInActivity extends AppCompatActivity {
    private EditText mUsername;
    private EditText mPassword;
    private Button mSignInButton;
    private InventoryDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        getSupportActionBar().hide();

        db = new InventoryDatabase(SignInActivity.this);

        mUsername = findViewById(R.id.etUsername);
        mPassword = findViewById(R.id.etPassword);
        mSignInButton = findViewById(R.id.btnSignIn);

        mSignInButton.setOnClickListener(view -> {
            String username = mUsername.getText().toString();
            String password = mPassword.getText().toString();

            int userID = signIn(username, password);
            if (userID >= 0) {
                // If we're able to sign in (meaning that the username/password credentials are correct)
                // then, we can open up the Inventory screen, and close this SignInActivity. That way,
                // if the user hits the back button from the Inventory screen, it will close the app, rather
                // than going back to the sign in screen.
                Intent intent = new Intent(SignInActivity.this, InventoryActivity.class);
                intent.putExtra(InventoryActivity.EXTRA_USER_ID, userID);
                startActivity(intent);
                finish();
            }
        });
    }

    public int signIn(String username, String password) {
        // When the user signs in, if they don't currently have an account,
        // one will automatically be created for them with the username/password
        // they entered.
        // Then, next time they sign in, they can use the credentials that were entered
        // previously
        UserFoundResult foundUser = db.getUser(username, password);

        switch (foundUser.result) {
            case FoundUser:
                Toast.makeText(SignInActivity.this, "Login successful!", Toast.LENGTH_LONG).show();
                return foundUser.userID;
            case NoUser:
                db.addUser(username, password);
                Toast.makeText(SignInActivity.this, "Added new user: " + username, Toast.LENGTH_LONG).show();
                return foundUser.userID;
            case IncorrectPassword:
                Toast.makeText(SignInActivity.this, "Incorrect password for user: " + username, Toast.LENGTH_LONG).show();
                return -1;
            default:
                return -1;
        }
    }
}