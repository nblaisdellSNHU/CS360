package com.example.inventoryapp;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.inventoryapp.database.InventoryDatabase;
import com.example.inventoryapp.model.InventoryItem;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {
    public static final String EXTRA_USER_ID = "com.example.inventoryapp.user_id";
    public static final String PREF_SMS_ENABLED = "com.example.inventoryapp.pref_sms_enabled";

    private InventoryDatabase db;
    private RecyclerView mRecyclerView;
    private InventoryAdapter mInventoryAdapter;

    private FloatingActionButton fabNewItem;

    private final ActivityResultLauncher<Intent> mEditLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
        if (result.getResultCode() == Activity.RESULT_OK) {
            Intent returnData = result.getData();
            if (returnData != null) {
                int itemID = returnData.getIntExtra(NewUpdateItemActivity.EXTRA_ITEM_ID, -1);
                String newItemName = returnData.getStringExtra(NewUpdateItemActivity.EXTRA_ITEM_NAME);
                int newItemCount = returnData.getIntExtra(NewUpdateItemActivity.EXTRA_ITEM_COUNT, 0);
                int origPosition = returnData.getIntExtra(NewUpdateItemActivity.EXTRA_ITEM_POSITION, -1);
                mInventoryAdapter.updateItem(origPosition, itemID, newItemName, newItemCount);
            }
        }
    });

    private final ActivityResultLauncher<Intent> mInsertLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
        if (result.getResultCode() == Activity.RESULT_OK) {
            Intent returnData = result.getData();
            if (returnData != null) {
                String newItemName = returnData.getStringExtra(NewUpdateItemActivity.EXTRA_ITEM_NAME);
                int newItemCount = returnData.getIntExtra(NewUpdateItemActivity.EXTRA_ITEM_COUNT, 0);
                int origPosition = returnData.getIntExtra(NewUpdateItemActivity.EXTRA_ITEM_POSITION, -1);
                mInventoryAdapter.addItem(origPosition, new InventoryItem(mInventoryAdapter.getNextID(), newItemName, newItemCount));
            }
        }
    });

    private final ActivityResultLauncher<Intent> mSMSLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
        if (result.getResultCode() == Activity.RESULT_OK) {
            Intent returnData = result.getData();
            if (returnData != null) {
                boolean useSMS = returnData.getBooleanExtra(EnableSMSActivity.EXTRA_ENABLE_SMS, false);
                mInventoryAdapter.setSMS(useSMS);
            }
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        SharedPreferences sharedPref = getApplicationContext().getSharedPreferences("myprefs", Context.MODE_PRIVATE);
        boolean smsEnabled = sharedPref.getBoolean(PREF_SMS_ENABLED, false);

        db = new InventoryDatabase(InventoryActivity.this);

        Intent userIDIntent = getIntent();
        int userID = userIDIntent.getIntExtra(EXTRA_USER_ID, -1);

        mRecyclerView = findViewById(R.id.rvInventoryList);
        RecyclerView.LayoutManager gridLayoutManager = new GridLayoutManager(getApplicationContext(), 2);
        mRecyclerView.setLayoutManager(gridLayoutManager);

        mInventoryAdapter = new InventoryAdapter(userID, smsEnabled);
        mInventoryAdapter.setOnClickListener(new InventoryAdapterListener() {
            @Override
            public void onEdit(int position, InventoryItem item) {
                // When the edit button on an item in the grid is selected, open the NewUpdateItemActivity
                // and pre-fill the data with the existing item
                Intent intent = new Intent(InventoryActivity.this, NewUpdateItemActivity.class);
                intent.putExtra(NewUpdateItemActivity.EXTRA_ITEM_NAME, item.getItemName());
                intent.putExtra(NewUpdateItemActivity.EXTRA_ITEM_COUNT, item.getItemCount());
                intent.putExtra(NewUpdateItemActivity.EXTRA_ITEM_POSITION, position);

                mEditLauncher.launch(intent);
            }

            @Override
            public void onDelete(int position, InventoryItem item) {
                // When the "delete" button on an item in the grid is selected,
                // remove it from the grid and database
                mInventoryAdapter.removeItem(position, item);
            }

            @Override
            public void onAdd(int position, InventoryItem item) {
                // When the "add (+)" button on an item in the grid, increment the count
                // for the item and update the item in the database
                mInventoryAdapter.incrementItemCount(position, item);
            }

            @Override
            public void onSubtract(int position, InventoryItem item) {
                // When the "subtract (-)" button on an item in the grid, decrement the count
                // for the item and update the item in the database
                mInventoryAdapter.decrementItemCount(position, item);
            }
        });
        mRecyclerView.setAdapter(mInventoryAdapter);

        fabNewItem = findViewById(R.id.fabAddNewItem);
        fabNewItem.setOnClickListener(view -> {
            // Open the NewUpdateItemActivity screen, without any data pre-filled, since we're creating
            // a new item
            Intent intent = new Intent(InventoryActivity.this, NewUpdateItemActivity.class);
            mInsertLauncher.launch(intent);
        });
    }

    public ArrayList<InventoryItem> getInventoryData(int userID) {
        return db.getAllInventoryItems(userID);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_app, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        if (item.getItemId() == R.id.enable_sms) {
            Intent intent = new Intent(InventoryActivity.this, EnableSMSActivity.class);
            mSMSLauncher.launch(intent);

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private class InventoryHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {

        private InventoryItem mItem;

        private TextView mItemName;
        private TextView mItemCount;
        private Button mButtonAdd;
        private Button mButtonSubtract;
        private ImageView mButtonEdit;
        private ImageView mButtonDelete;

        public InventoryHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.layout_inventory_item, parent, false));
            itemView.setOnClickListener(this);

            mItemName = itemView.findViewById(R.id.txtInventoryItemName);
            mItemCount = itemView.findViewById(R.id.txtNumInInventory);
            mButtonAdd = itemView.findViewById(R.id.btnAdd);
            mButtonSubtract = itemView.findViewById(R.id.btnSubtract);
            mButtonEdit = itemView.findViewById(R.id.imgEdit);
            mButtonDelete = itemView.findViewById(R.id.imgDelete);
        }

        public void bind(InventoryItem item, int position, InventoryAdapterListener listener) {
            mItem = item;

            mItemName.setText(mItem.getItemName());
            mItemCount.setText(String.valueOf(mItem.getItemCount()));

            // Register our listener for the different actions that can be taken on our
            // individual items in the grid, and associate each listener with the appropriate
            // element
            if (listener != null) {
                mButtonEdit.setOnClickListener(view -> {
                    listener.onEdit(this.getAdapterPosition(), item);
                });

                mButtonDelete.setOnClickListener(view -> {
                    listener.onDelete(this.getAdapterPosition(), item);
                });

                mButtonAdd.setOnClickListener(view -> {
                    listener.onAdd(this.getAdapterPosition(), item);
                });

                mButtonSubtract.setOnClickListener(view -> {
                    listener.onSubtract(this.getAdapterPosition(), item);
                });
            }
        }

        @Override
        public void onClick(View view) {
        }
    }

    // An interface for our list adapter, so define each of the actions
    // that can be taken on an individual item
    public interface InventoryAdapterListener {
        void onEdit(int position, InventoryItem item);
        void onDelete(int position, InventoryItem item);
        void onAdd(int position, InventoryItem item);
        void onSubtract(int position, InventoryItem item);
    }

    private class InventoryAdapter extends RecyclerView.Adapter<InventoryHolder> {
        private int mID;
        private ArrayList<InventoryItem> mInventoryList;
        private boolean mSMSEnabled;

        private final int SMS_ITEM_COUNT_THRESHOLD = 5;

        private InventoryAdapterListener mListener;

        public InventoryAdapter(int userID, boolean smsEnabled) {
            mID = userID;
            mInventoryList = getInventoryData(mID);
            mSMSEnabled = smsEnabled;
        }

        public void setOnClickListener(InventoryAdapterListener listener) {
            mListener = listener;
        }

        public int getNextID() {
            if (mInventoryList.size() == 0) { return 1; }
            return mInventoryList.get(0).getID() + 1;
        }

        public void setSMS(boolean useSMS) {
            mSMSEnabled = useSMS;
        }

        // If the user has chosen to enable SMS for the app, assemble a text message
        // denoting the item and count for an item whose count has gone below the set
        // threshold (of 5), and sent the text message
        public void sendSMS(InventoryItem item) {
            if (mSMSEnabled) {
                StringBuilder sb = new StringBuilder();
                sb.append("Low Inventory Alert!\n\n");
                sb.append("Item Name: " + item.getItemName() + "\n");
                sb.append("Item Count: " + item.getItemCount());

                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage("+15555215554", null, sb.toString(), null, null);
            }
        }

        public void removeItem(int position, InventoryItem item) {
            // Find the item in the list
            int idx = position;
            if (idx >= 0) {
                // Remove the item from the list
                mInventoryList.remove(idx);

                db.deleteInventoryItem(mID, item);

                // Notify the adapter (for the RecyclerView) of the removal
                // so we can have some animation for when it gets removed
                notifyItemRemoved(idx);
            }
        }

        public void updateItem(int position, int itemID, String itemName, int itemCount) {
            InventoryItem currItem = mInventoryList.get(position);
            currItem.setItemName(itemName);
            currItem.setItemCount(itemCount);
            notifyItemChanged(position);
            db.updateInventoryItem(mID, currItem);

            if (currItem.getItemCount() <= SMS_ITEM_COUNT_THRESHOLD) {
                sendSMS(currItem);
            }
        }

        public void addItem(int position, InventoryItem item) {
            // Add the new subject at the beginning of the list
            mInventoryList.add(0, item);

            db.addInventoryItem(mID, item);

            // Notify the adapter that item was added to the beginning of the list
            notifyItemInserted(0);

            // Scroll to the top
            mRecyclerView.scrollToPosition(0);
        }

        public void incrementItemCount(int position, InventoryItem item) {
            int myPos = position;
            InventoryItem curr = mInventoryList.get(myPos);
            int currCount = curr.getItemCount();
            curr.setItemCount(currCount + 1);

            notifyItemChanged(myPos);

            db.updateInventoryItem(mID, curr);
        }

        public void decrementItemCount(int position, InventoryItem item) {
            int myPos = position;
            InventoryItem curr = mInventoryList.get(myPos);
            int currCount = curr.getItemCount();
            if (currCount > 0) {
                curr.setItemCount(currCount - 1);
                notifyItemChanged(myPos);
                db.updateInventoryItem(mID, curr);

                if (currCount - 1 <= SMS_ITEM_COUNT_THRESHOLD) {
                    sendSMS(curr);
                }
            }
        }

        @NonNull
        @Override
        public InventoryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());
            return new InventoryHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(InventoryHolder holder, int position) {
            InventoryItem item = mInventoryList.get(position);
            holder.bind(item, position, mListener);
        }

        @Override
        public int getItemCount() {
            return mInventoryList.size();
        }
    }
}