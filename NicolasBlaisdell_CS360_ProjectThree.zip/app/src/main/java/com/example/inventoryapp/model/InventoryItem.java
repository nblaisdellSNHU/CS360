package com.example.inventoryapp.model;

public class InventoryItem {
    private int mID;
    private String mItemName;
    private int mItemCount;

    public InventoryItem(int id, String itemName, int itemCount) {
        setID(id);
        setItemName(itemName);
        setItemCount(itemCount);
    }

    public int getID() { return mID; }

    public void setID(int id) { mID = id; }

    public String getItemName() {
        return mItemName;
    }

    public void setItemName(String itemName) {
        mItemName = itemName;
    }

    public int getItemCount() {
        return mItemCount;
    }

    public void setItemCount(int count) {
        mItemCount = count;
    }
}
