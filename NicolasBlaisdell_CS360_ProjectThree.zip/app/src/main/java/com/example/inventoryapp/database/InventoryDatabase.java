package com.example.inventoryapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.inventoryapp.model.InventoryItem;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

public class InventoryDatabase extends SQLiteOpenHelper {
    private static final String TAG = "InventoryDatabase";

    private static final String DATABASE_NAME = "InventoryDB";
    private static final int VERSION = 5;

    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    // "User" table to keep track of the different users in the app, allowing for multiple
    // accounts with different inventories
    private static final class UserTable {
        private static final String TABLE_NAME = "inventory_users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    // "Inventory" table, to keep track of all the items and their counts
    // Note the "COL_USER_ID", which references the "User" table
    private static final class InventoryTable {
        private static final String TABLE_NAME = "inventory_list";
        private static final String COL_USER_ID = "user_id";
        private static final String COL_ID = "_id";
        private static final String COL_ITEM_NAME = "item_name";
        private static final String COL_ITEM_COUNT = "item_count";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + UserTable.TABLE_NAME + " (" +
            UserTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            UserTable.COL_USERNAME + " TEXT, " +
            UserTable.COL_PASSWORD + " TEXT)"
        );

        db.execSQL("CREATE TABLE " + InventoryTable.TABLE_NAME + " (" +
            InventoryTable.COL_ID + " INTEGER, " +
            InventoryTable.COL_USER_ID + " INTEGER," +
            InventoryTable.COL_ITEM_NAME + " TEXT, " +
            InventoryTable.COL_ITEM_COUNT + " INTEGER," +
            "PRIMARY KEY(" + InventoryTable.COL_ID + ", " + InventoryTable.COL_USER_ID + ")," +
            "FOREIGN KEY(" + InventoryTable.COL_USER_ID + ") REFERENCES " + UserTable.TABLE_NAME + "(" + UserTable.COL_ID + "))"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + UserTable.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + InventoryTable.TABLE_NAME);

        onCreate(db);
    }

    // Represents the 3 states that can happen when a user logs in
    public enum UserFound {
        NoUser,
        IncorrectPassword,
        FoundUser
    }

    // An object which wraps the state of what occurred during login, as well as a return value
    // for a potentially logged in user
    public static class UserFoundResult {
        public String username;
        public int userID;
        public UserFound result;

        public UserFoundResult(int _userID, String _username, UserFound _result) {
            userID = _userID;
            username = _username;
            result = _result;
        }
    }

    // Add a new user to the "Users" table in the database
    // We're encrypting the password before storing it, for better security
    public void addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, username);
        values.put(UserTable.COL_PASSWORD, encrypt(password));

        db.insert(UserTable.TABLE_NAME, null, values);
    }


    public UserFoundResult getUser(String username, String password) {
        UserFound result;
        int userID = 0;
        String foundUser = null;

        SQLiteDatabase db = getReadableDatabase();

        long totalUserCount = DatabaseUtils.queryNumEntries(db, UserTable.TABLE_NAME);

        Cursor cursor =
            db.query(
                UserTable.TABLE_NAME,
                new String[] { UserTable.COL_ID, UserTable.COL_USERNAME, UserTable.COL_PASSWORD },
                UserTable.COL_USERNAME + " = ?",
                new String[] { username },
                null,
                null,
                null
            );
        if (cursor.moveToFirst()) {
            userID = cursor.getInt(0);
            foundUser = cursor.getString(1);
            String passDB = cursor.getString(2);

            // Compare the stored password to an encrypted version of the password
            // the user entered password, to see if they match
            String currPassEnc = encrypt(password);

            if (passDB.equals(currPassEnc)) {
                result = UserFound.FoundUser;
            } else {
                result = UserFound.IncorrectPassword;
            }
        } else {
            result = UserFound.NoUser;
            userID = (int)totalUserCount + 1;
        }
        cursor.close();

        return new UserFoundResult(userID, foundUser, result);
    }

    // Takes a String and returns a MD5-encrypted hash string for the purpose
    // of encrypting passwords
    public static String encrypt(final String s) {
        try {
            // Create MD5 Hash
            MessageDigest digest = java.security.MessageDigest
                    .getInstance("MD5");
            digest.update(s.getBytes());
            byte[] messageDigest = digest.digest();

            // Create Hex String
            StringBuilder hexString = new StringBuilder();
            for (byte aMessageDigest : messageDigest) {
                String h = Integer.toHexString(0xFF & aMessageDigest);
                while (h.length() < 2)
                    h = "0" + h;
                hexString.append(h);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        return "";
    }

    // Get the entire list of inventory items from the database for the given user
    public ArrayList<InventoryItem> getAllInventoryItems(int userID) {
        ArrayList<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        String query =
            "SELECT i." + InventoryTable.COL_ID + ", i." + InventoryTable.COL_ITEM_NAME + ", i." + InventoryTable.COL_ITEM_COUNT +
            " FROM " + InventoryTable.TABLE_NAME + " i " +
            " JOIN " + UserTable.TABLE_NAME + " u " +
            " ON i." + InventoryTable.COL_USER_ID + " = u." + UserTable.COL_ID +
            " AND u." + UserTable.COL_ID + " = ? " +
            " ORDER BY i." + InventoryTable.COL_ID + " DESC";
        Cursor cursor = db.rawQuery(query, new String[] { String.valueOf(userID) });
        if (cursor.moveToFirst()) {
            do {
                int itemID = cursor.getInt(0);
                String itemName = cursor.getString(1);
                int itemCount = Integer.parseInt(cursor.getString(2));
                items.add(new InventoryItem(itemID, itemName, itemCount));
            } while (cursor.moveToNext());
        }
        cursor.close();

        return items;
    }

    // Add a new InventoryItem to the database
    public void addInventoryItem(int userID, InventoryItem item) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_USER_ID, userID);
        values.put(InventoryTable.COL_ID, item.getID());
        values.put(InventoryTable.COL_ITEM_NAME, item.getItemName());
        values.put(InventoryTable.COL_ITEM_COUNT, item.getItemCount());

        db.insert(InventoryTable.TABLE_NAME, null, values);
    }

    // Update an inventory item in the database
    // This will overwrite the item name and count for the given "item" in the database
    public void updateInventoryItem(int userID, InventoryItem item) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_ITEM_NAME, item.getItemName());
        values.put(InventoryTable.COL_ITEM_COUNT, item.getItemCount());

        String whereClause = InventoryTable.COL_USER_ID + " = ? AND " + InventoryTable.COL_ID + " = ?";
        String[] whereArgs = new String[] { String.valueOf(userID), String.valueOf(item.getID()) };

        db.update(InventoryTable.TABLE_NAME, values, whereClause, whereArgs);
    }

    // delete the inventory item in the database
    public void deleteInventoryItem(int userID, InventoryItem item) {
        SQLiteDatabase db = getWritableDatabase();

        String whereClause = InventoryTable.COL_USER_ID + " = ? AND " + InventoryTable.COL_ID + " = ?";
        String[] whereArgs = new String[] { String.valueOf(userID), String.valueOf(item.getID()) };

        db.delete(InventoryTable.TABLE_NAME, whereClause, whereArgs);
    }
}
