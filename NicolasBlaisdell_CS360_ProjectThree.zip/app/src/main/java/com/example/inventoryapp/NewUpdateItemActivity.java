package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.inventoryapp.model.InventoryItem;

public class NewUpdateItemActivity extends AppCompatActivity {
    public static final String EXTRA_ITEM_ID = "com.example.inventoryapp.item_id";
    public static final String EXTRA_ITEM_NAME = "com.example.inventoryapp.item_name";
    public static final String EXTRA_ITEM_COUNT = "com.example.inventoryapp.item_count";
    public static final String EXTRA_ITEM_POSITION = "com.example.inventoryapp.item_position";

    private InventoryItem mItem;
    private int mPosition;

    private EditText etItemName;
    private EditText etItemCount;
    private Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_update_item);

        etItemName = findViewById(R.id.etItemName);
        etItemCount = findViewById(R.id.etItemCount);
        btnSave = findViewById(R.id.btnSave);

        // Get data from the calling InventoryActivity. If there's data in the extras,
        // that means we're updating an existing inventory item. If there's no data,
        // (mPosition == -1), then we're creating a new inventory item.
        Intent intent = getIntent();
        int itemID = intent.getIntExtra(EXTRA_ITEM_ID, -1);
        String itemName = intent.getStringExtra(EXTRA_ITEM_NAME);
        int itemCount = intent.getIntExtra(EXTRA_ITEM_COUNT, 0);
        mPosition = intent.getIntExtra(EXTRA_ITEM_POSITION, -1);

        if (mPosition >= 0) {
            setTitle("Update Item");
            mItem = new InventoryItem(itemID, itemName, itemCount);

            // Pre-fill the information for the item being updated
            etItemName.setText(mItem.getItemName());
            etItemCount.setText(String.valueOf(mItem.getItemCount()));
        } else {
            setTitle("Create New Inventory Item");
        }

        // When the save button is hit...
        btnSave.setOnClickListener(view -> {
            // Extract the values entered by the user for this item
            String newItemName = etItemName.getText().toString();
            int newItemCount = Integer.parseInt(etItemCount.getText().toString());

            // Assemble the data and return it back to the InventoryActivity
            // so it can properly add/update the item
            Intent returnData = new Intent();
            returnData.putExtra(EXTRA_ITEM_ID, itemID);
            returnData.putExtra(EXTRA_ITEM_NAME, newItemName);
            returnData.putExtra(EXTRA_ITEM_COUNT, newItemCount);
            returnData.putExtra(EXTRA_ITEM_POSITION, mPosition);

            setResult(RESULT_OK, returnData);
            finish();
        });
    }
}